$(window).on("load",function(){
	
	setTimeout(function(){$('.done').addClass("drawn");},500)
	
});