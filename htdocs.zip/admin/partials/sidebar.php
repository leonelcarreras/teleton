<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

<!-- Sidebar - Brand -->
<a class="sidebar-brand d-flex align-items-center justify-content-center">
    <img class="logo-sidebar" src="./img/Logo-eSports-Teleton-RGB-1.png">
</a>



<!-- Nav Item - Dashboard -->
<li class="nav-item active">
    <a class="nav-link" href="/admin">
        <i class="fas fa-fw fa-tachometer-alt"></i>
        <span>Dashboard</span></a>
</li>

<!-- Divider -->
<hr class="sidebar-divider">

<!-- Heading -->
<div class="sidebar-heading">
    Inscritos
</div>

<!-- Nav Item - Tables -->
<li class="nav-item">
    <a class="nav-link" href="rocketleague">
        <i class="fas fa-fw fa-table"></i>
        <span>Rocket League</span></a>
</li>
<li class="nav-item">
    <a class="nav-link" href="fifa11v11">
        <i class="fas fa-fw fa-table"></i>
        <span>FIFA 23 11v11</span></a>
</li>
<li class="nav-item">
    <a class="nav-link" href="fifa1v1">
        <i class="fas fa-fw fa-table"></i>
        <span>FIFA 23 1v1</span></a>
</li>
<li class="nav-item">
    <a class="nav-link" href="granturismo7">
        <i class="fas fa-fw fa-table"></i>
        <span>Gran Turismo 7</span></a>
</li>

<!-- Divider -->
<hr class="sidebar-divider d-none d-md-block">

<!-- Sidebar Toggler (Sidebar) -->
<div class="text-center d-none d-md-inline">
    <button class="rounded-circle border-0" id="sidebarToggle"></button>
</div>



</ul>
