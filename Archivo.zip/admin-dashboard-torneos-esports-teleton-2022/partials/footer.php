<footer class="sticky-footer bg-white">
<div class="container">

    <center>
      <div class="copyright">
        &copy; 2022 <strong><a target="_blank" href="https://www.teleton.cl/" style="color:#e63742;">Teletón Chile</a></strong> en conjunto a <a href="https://www.instagram.com/anfv_chile/" target="_blank" style="color:#e63742;">ANFV Chile</a> & <a target="_blank" href="https://www.instagram.com/gamingarenacl/" style="color:#e63742;">Gaming Arena</a>. Todos los Derechos Reservados.
        <div class="social-links mt-3"> 


          <a href="https://www.facebook.com/teletonchile" target="_blank" class="facebook">
                        <i class="bi bi-facebook"></i>
          </a> 

          <a href="https://www.youtube.com/channel/UCfGbXA1P_n-ggNdrxw1E0Aw" target="_blank" class="twitter">
            <i class="bi bi-youtube"></i>
          </a> 

          <a href="https://www.instagram.com/teleton_chile/" target="_blank" class="instagram">
                        <i class="bi bi-instagram"></i>
          </a> 

          <a href="https://twitter.com/Teleton" target="_blank" class="twitter">
            <i class="bi bi-twitter"></i>
          </a> 

          <a href="https://cl.linkedin.com/company/teleton" target="_blank" class="linkedin">
              <i class="bi bi-linkedin"></i>
          </a>

          <a href="https://www.tiktok.com/@teletoncl" target="_blank" class="linkedin">
              <i class="bi bi-tiktok"></i>
          </a>

          <a href="https://www.twitch.tv/GamingArenaCL" target="_blank" class="linkedin">
                        <i class="bi bi-twitch"></i>
          </a>

          <a href="https://discord.gg/2Cj2r6qwjz" target="_blank" class="linkedin">
              <i class="bi bi-discord"></i>
          </a>

           
          
          

          </div>
          </center>
      </div>


    </div>

            </footer>